# Angular-based-File-analyzer
It is an angular based spring boot supported application that works on analyzing files for rectifying and identification tasks.
